import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_srvs.srv import SetBool
from cv_bridge import CvBridge
import cv2
from rclpy.qos import QoSProfile

class ImageConversionNode(Node):
    def __init__(self):
        super().__init__('image_conversion')
        self.bridge = CvBridge()

        # Default to color mode
        self.mode = False  # False for color, True for grayscale

        # Create a subscriber
        self.image_subscriber = self.create_subscription(
            Image,
            '/image_raw',
            self.image_callback,
            QoSProfile(depth=10)
        )

        # Create a service to change the mode
        self.srv = self.create_service(
            SetBool,
            '/image_conversion/set_conversion_mode',
            self.change_mode
        )

        # Publisher for processed images
        self.image_publisher = self.create_publisher(
            Image,
            '/converted_image',
            QoSProfile(depth=10)
        )

    def image_callback(self, msg):
        try:
            # Convert ROS image to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(msg, 'bgr8')

            if self.mode:  # Grayscale mode
                processed_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
                processed_image = cv2.cvtColor(processed_image, cv2.COLOR_GRAY2BGR)  # Convert back to 3 channels
            else:  # Color mode
                processed_image = cv_image

            # Publish processed image
            processed_msg = self.bridge.cv2_to_imgmsg(processed_image, 'bgr8')
            self.image_publisher.publish(processed_msg)

        except Exception as e:
            self.get_logger().error(f'Error processing image: {e}')

    def change_mode(self, request, response):
        self.mode = request.data
        response.success = True
        response.message = f"Mode changed to {'Grayscale' if self.mode else 'Color'}"
        return response

def main(args=None):
    rclpy.init(args=args)
    node = ImageConversionNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
